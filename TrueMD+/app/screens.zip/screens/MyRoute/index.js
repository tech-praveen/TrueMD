import React, { Component } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import NavigationBar from '../../components/NavigationBar';
import { images } from '../../assets/images';
import TextWithIcon from '../../components/TextWithIcon';
import ContextMenuButton from '../../components/ContextMenuButton';

export default class MyRoute extends Component {
  render() {
    return (
      <View style={styles.container}>
        <NavigationBar
          title='My Routes'
          showBackButton={Boolean(true)}
          backButtonAction={() => this.props.navigation.pop()}
        />

        <FlatList
          data={[
            { key: 'Devin' },
            { key: 'Dan' },
            { key: 'Dominic' },
            { key: 'Jackson' },
            { key: 'James' },
            { key: 'Joel' },
            { key: 'John' },
            { key: 'Jillian' },
            { key: 'Jimmy' },
            { key: 'Julie' },
          ]}
          renderItem={({ item }) => <View style={{ height: 110, backgroundColor: 'white', margin: 5, padding: 5, paddingLeft: 5 }}>
            <Text style={styles.item}>{item.key}</Text>
            <TextWithIcon
              icon={images.pause}
              title={'hello'} />
            <TextWithIcon
              icon={images.pause}
              title={'world'}
            />
            <View style={{ height: 40, width: '100%', alignItems: 'flex-end', marginTop: 5  }} >
            <View style={{  flexDirection: 'row', justifyContent: 'center' }} >
            <ContextMenuButton icon={images.email} onPress={() => console.log('delete')}/>
            <ContextMenuButton icon={images.email} onPress={() => console.log('edit')}/>
            <ContextMenuButton icon={images.email} onPress={() => console.log('copy')}/>
            </View>
            </View>
          </View>}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f8ff'
    //  paddingTop: 22
  },
  item: {
    // paddingLeft: 5,
    fontSize: 16,
    // height: 44,
  },
})
