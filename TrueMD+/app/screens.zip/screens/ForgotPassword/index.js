import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import InputField from '../../components/InputField';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import { Formik } from 'formik';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import * as Animatable from "react-native-animatable";
import { images } from '../../assets/images';
import LoginSchema from '../../utils/validations';
import NavigationBar from '../../components/NavigationBar';
import * as Yup from 'yup';
import { connect } from 'react-redux';
import UserActions from '../../actions';

const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/

const ForgotPasswordSchema = Yup.object().shape({
  "email": Yup.string()
  .trim()
  .required('Please enter your email')
  .matches(emailRegex, 'Please enter valid email'),
})
class ForgotPassword extends Component {
  static navigationOptions = ({ navigation }) => { // Custom Navigation
    return {
      headerLeft: (
        <TouchableOpacity
          style={{ height: 40, width: 40, backgroundColor: 'red' }}
          onPress={() => {
            navigation.navigate('Welcome');
          }
          }
        />
      ),
    };
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoaded: true
    }
  }

  checkErrors = (props) => { // Check Errors when SignIn button pressed
    if (props.dirty) {
      if (props.errors.email) {
        Alert.alert('Please enter valid phone no');
        return;
      }
      props.submitForm();

    } else {
        Alert.alert('PLease enter valid email address');
    }
  }

  componentDidMount() {
  }
  popBack() {
    this.props.navigation.popBack();
  }
  checkError = (props, fieldName) => { // Check Error Individually for every field
    return props.errors[fieldName] && (props.touched[fieldName] || props.submitCount > 0)
  }

  onSignUpClicked() {
    this.props.navigation.navigate('SignUp');
  }

  onForgetPasswordClicked() {
    this.props.navigation.navigate('ForgetPassword');
    // Services.NavigationService.navigate(AppConstant.Navigations.Onboarding.FORGOTPASSWORD)
  }

  render() {
    let formikProps;
    return (
      <Formik
        validationSchema={ForgotPasswordSchema}
        initialValues={{ type: 'login', email: '', errors: {} }}
        onSubmit={(values, { resetForm }) => {
          let data = {
            email: values.email,
          }
          this.props.userforgotPasswordRequest(data);
        }}
      >
        {props => {
          formikProps = props;
          return (
            <View style={styles.mainContainer}>
              <NavigationBar
                // title='test'
                showBackButton={Boolean(true)}
                // backButtonImage={images.backbutton}
                backButtonAction={() => this.props.navigation.pop()}
                // backButtonAction={() => this.sideMenuAction()}
                hideRightView={true}
              />
              <KeyboardAwareScrollView
                enableOnAndroid={true}
                contentContainerStyle={styles.mainContainer}
                keyboardShouldPersistTaps='handled' >
                <React.Fragment>
                  {
                    this.state.isLoaded ?
                      <View style={styles.container}>
                        <Animatable.View animation="flipInX"
                          duration={1000}
                          delay={200} style={styles.welcomeImage}>
                          <Image source={images.appLogo} />
                        </Animatable.View>
                        <Animatable.View animation="lightSpeedIn"
                          duration={1000}
                          delay={400} >
                          <InputField
                            label={'Email'}
                            onChangeText={props.handleChange('email')}
                            onBlur={props.handleBlur('email')}
                            value={props.values.email.trim()}
                            maxLength={50}
                            keyboardType={'email-address'}
                          />
                          {this.checkError(props, 'email')
                            && <Text style={styles.error} >
                              {props.errors.email}
                            </Text>}
                        </Animatable.View>
                        <Animatable.View animation="fadeInUp"
                          duration={500}
                          delay={900} style={styles.bottomContainer}>
                          <TouchableOpacity
                            style={styles.signupStyle}
                            onPress={() => this.checkErrors(formikProps)}
                            >
                            <Text style={{ color: 'white', fontSize: 16 }}>
                              {'Recover Password'}
                            </Text>
                          </TouchableOpacity>
                        </Animatable.View>
                      </View>
                      : null}
                </React.Fragment>
              </KeyboardAwareScrollView>
            </View>
          )
        }}
      </Formik>
    );
  }
}


const styles = StyleSheet.create({
  mainContainer: {
    flexGrow: 1,
    backgroundColor: '#f0f8ff'
  },
  container: {
    // backgroundColor: AppConstant.Colors.navigationColor,
    flex: 1,
    paddingHorizontal: 20
  },
  bottomContainer: {
    flex: 1,
    justifyContent: 'space-between',
    paddingTop: hp('2%')
  },
  welcomeImage: {
    marginBottom: hp('10%')
  },
  mainHeading: {
    // color: AppConstant.Colors.labelText,
    fontSize: 50
  },
  subHeading: {
    // color: AppConstant.Colors.golden,
    marginBottom: 30
  },
  forgotPasswordContainer: {
    width: 'auto'
  },
  forgotPasswordOuterContainer: {
    alignItems: 'flex-start'
  },
  forgotPassword: {
    // color: AppConstant.Colors.forgotPassword,
    fontSize: wp('3.2%'),
    // fontFamily: AppConstant.Fonts.quicksand_medium,
    marginTop: 10,
    // opacity: 0.8,
    // borderBottomWidth: 1,
    // paddingBottom: 2,
    // borderColor: AppConstant.Colors.forgotPassword

  },
  error: {
    color: 'red',
    opacity: 0.91,
    alignSelf: 'flex-start',
    fontSize: wp('4%'),
    marginLeft: 3,
    // fontFamily: AppConstant.Fonts.quicksand_regular,
  },
  needAccountOuterContainer: {
    alignItems: 'center'
  },
  needAccountInnerContainer: {
    width: 'auto',
    opacity: 0.8,
  },
  needAccountText: {
    textAlign: 'center',
    // fontFamily: AppConstant.Fonts.quicksand_regular,
    // color: AppConstant.Colors.labelText,
    fontSize: wp('3.6%'),
    // borderBottomWidth: 1,
    paddingBottom: 2,
    // borderColor: AppConstant.Colors.labelText
  },
  needAccountView: {
    marginBottom: hp('3%'),
    opacity: 0.8,
    borderBottomWidth: 1,
    paddingBottom: 2,
    // borderColor: AppConstant.Colors.labelText
  },
  forgotView: {
    opacity: 0.8,
    borderBottomWidth: 1,
    paddingBottom: 2,
    // borderColor: AppConstant.Colors.forgotPassword
  },
  signupStyle: {
    backgroundColor: '#00579E',
    width: '90%',
    alignSelf: 'center',
    height: 50,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    // paddingTop: 15,
    borderRadius: 25,
  },
  imagebackground: {
    width: '100%',
    height: '100%'
  },

})

const mapStateToProps = state => ({
  forgotpassword: state.authentication.forgotPasswordResponse,
  isLoading: state.authentication.isLoading,
});

const mapDispatchToProps = () => UserActions;
const ForgotPasswordScreen = connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);
export default ForgotPasswordScreen;
