import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, Keyboard, Image } from 'react-native';
import InputField from '../../components/InputField';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import { Formik } from "formik";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import * as Animatable from "react-native-animatable";
import { images } from '../../assets/images';
import NavigationBar from '../../components/NavigationBar';
import * as Yup from 'yup';
import { connect } from 'react-redux';
import UserActions from '../../actions';

const NameRegex = /^[a-zA-Z-]+$/;
const HypenRegex = /^(?=.*[a-zA-Z])[a-zA-Z-]+$/;
const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
const passwordDot = /^[^.]+$/;
const NumberRegex = /^[0-9]+$/;

const SignupSchema = Yup.object().shape({
  "first_name": Yup.string()
    .min(2, 'First name should be 2-30 characters long')
    .required('Please enter your first name'),
  // .matches(NameRegex, { excludeEmptyString: true, message: 'Please enter valid first name' }),
  // .matches(HypenRegex, { excludeEmptyString: true, message: 'Only hypens are not allowed' }),
  // "last_name": Yup.string()
  //   .trim()
  //   .min(2, 'Last name should be 2-30 characters long')
  //   .required('Please enter your last name')
  //   .matches(NameRegex, { excludeEmptyString: true, message: 'Please enter valid last name' })
  //   .matches(HypenRegex, { excludeEmptyString: true, message: 'Only hypens are not allowed' }),

  "email": Yup.string()
    .trim()
    .required('Please enter your email')
    .matches(emailRegex, 'Please enter valid email'),

  "password": Yup.string()
    .trim()
    .required('Please enter your password')
    .matches(passwordDot, { excludeEmptyString: true, message: 'Please enter valid password' })
    .min(6, 'Password should be at least 8 characters long')
    .max(16, 'Password should be less than 16 characters'),

  "passwordConfirm": Yup.string()
    .trim()
    .required('Please enter your password')
    .matches(passwordDot, { excludeEmptyString: true, message: 'Please enter valid password' })
    .min(6, 'Password should be at least 8 characters long')
    .max(16, 'Password should be less than 16 characters'),

  "phoneNumber": Yup.string()
    .trim()
    .required('Please enter phone number')
    .min(10, 'Please enter valid phone number')
    .max(10, 'Please enter valid phone number')
    .matches(NumberRegex, { excludeEmptyString: true, message: 'Please enter valid phone number' }),

  "privacy": Yup
    .boolean()
    .oneOf([true], 'Please accept terms of service & privacy policy'),
});

class Signup extends Component {

  constructor(props) { // To initialize states and variables
    super(props);
    this.state = {
      hidePassword: true,
      isLoaded: true
    }
  }

  checkErrors = (props) => { // Check Errors when SignUp button pressed
    Keyboard.dismiss();
    if (props.dirty) {
      if (props.errors.first_name) {
        Alert.alert('Enter first name');
        return;
      }
      if (props.errors.email) {
        Alert.alert('Enter email');
        return;
      }
      if (props.errors.phoneNumber) {
        Alert.alert('Enter phone number');
        return;
      }
      if (props.errors.password) {
        Alert.alert('Enter password');
        return;
      }
      if (props.errors.passwordConfirm) {
        Alert.alert('Enter confirm password');
        return;
      }
      props.submitForm();

    } else {
      Alert.alert('All fields are mendatory');
    }
  }

  checkError = (props, fieldName) => { // Check Error Individually for every field
    return props.errors[fieldName] && (props.touched[fieldName] || props.submitCount > 0)
  }

  togglePrivacy = (props) => { // To toggle checkbox of Terms of Service and Privacy Policy
    props.setFieldValue('privacy', !props.values.privacy);
  }

  onPressTitle(data) {
    alert(data)
    // const urlService = data === 'Policy' ? AppConstant.Common.privacyPolicy : AppConstant.Common.termAndCondition;
    // this.props.navigation.navigate(AppConstant.Navigations.Onboarding.WEB_VIEW, { url: urlService });
  }

  onPressLogin() {
    this.props.navigation.navigate('Login');
  }

  render() {
    let formikProps;
    console.log('this.props.navigation', this.props.navigation)
    return (
      <View style={styles.mainContainer}>
        <NavigationBar
          showBackButton={Boolean(true)}
          backButtonAction={() => this.props.navigation.pop()}
          hideRightView={true}
        />
        <KeyboardAwareScrollView
          enableOnAndroid={true}
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps='handled' >
          <Formik
            validationSchema={SignupSchema}
            initialValues={{ type: 'signup', privacy: false, first_name: '', passwordConfirm: '', password: '', email: '', phoneNumber: '', errors: {} }}
            onSubmit={(values, { resetForm }) => {
              let body = {
                email: values.email,
                name: values.first_name,
                password: values.password,
                password_comfirmation: values.passwordConfirm,
                username: values.phoneNumber,
                role: 'customer',
                app_name: 'circuit'
              }
              this.props.userSignUpRequest(body);
            }}
          >
            {props => {
              formikProps = props;
              return (
                <React.Fragment>
                  {
                    this.state.isLoaded ? <View style={styles.container}>
                      <Animatable.View animation="flipInX"
                        duration={1000}
                        delay={200}
                        style={styles.welcomeImage}>
                        <Image source={images.appLogo} />
                      </Animatable.View>
                      <Animatable.View animation="lightSpeedIn"
                        duration={1000}
                        delay={500}>
                        <InputField
                          label={'Name'}
                          maxLength={30}
                          onChangeText={props.handleChange('first_name')}
                          onBlur={props.handleBlur('first_name')}
                          value={props.values.first_name}
                        />
                        {this.checkError(props, 'first_name')
                          && <Text style={styles.error} >
                            {props.errors.first_name}
                          </Text>}
                      </Animatable.View>
                      <Animatable.View animation="lightSpeedIn"
                        duration={1000}
                        delay={600}>
                        <InputField
                          onChangeText={props.handleChange('phoneNumber')}
                          onBlur={props.handleBlur('phoneNumber')}
                          value={props.values.phoneNumber}
                          maxLength={50}
                          label={'Mobile Number'}
                        />
                        {this.checkError(props, 'phoneNumber') && (
                          <Text style={styles.error}>
                            {props.errors.phoneNumber}
                          </Text>
                        )}

                      </Animatable.View>
                      <Animatable.View animation="lightSpeedIn"
                        duration={1000}
                        delay={700}>
                        <InputField
                          onChangeText={props.handleChange('email')}
                          onBlur={props.handleBlur('email')}
                          value={props.values.email.trim()}
                          maxLength={50}
                          keyboardType={'email-address'}
                          label={'Email'}
                        />
                        {this.checkError(props, 'email')
                          && <Text style={styles.error} >
                            {props.errors.email}
                          </Text>}
                      </Animatable.View>
                      <Animatable.View animation="lightSpeedIn"
                        duration={1000}
                        delay={800}>
                        <InputField
                          onChangeText={props.handleChange('password')}
                          onBlur={props.handleBlur('password')}
                          value={props.values.password.trim()}
                          maxLength={30}
                          // secureTextEntry={this.state.hidePassword}
                          label={'Password'}
                        />
                        {this.checkError(props, 'password')
                          && <Text style={styles.error} >
                            {props.errors.password}
                          </Text>}
                      </Animatable.View>
                      <Animatable.View animation="lightSpeedIn"
                        duration={1000}
                        delay={600}>
                        <InputField
                          onChangeText={props.handleChange('passwordConfirm')}
                          onBlur={props.handleBlur('passwordConfirm')}
                          value={props.values.passwordConfirm.trim()}
                          // secureTextEntry={true}
                          label={'Confirm Password'}
                          maxLength={30}
                        />
                        {this.checkError(props, 'passwordConfirm')
                          && <Text style={styles.error} >
                            {props.errors.passwordConfirm}
                          </Text>}
                      </Animatable.View>
                      <Animatable.View animation="lightSpeedIn"
                        duration={1000}
                        delay={900}
                        style={styles.termsConditionOuterContainer} >
                        <View style={styles.termsConditionInnerContainer}>
                          <TouchableOpacity
                            style={styles.checkImage}
                            onPress={() => {
                              this.togglePrivacy(props)
                            }}>
                            <Image source={props.values.privacy
                              ? images.checkIcon
                              : images.unCheckIcon}
                            />
                          </TouchableOpacity>
                          <View style={styles.termContainer}>
                            <Text style={styles.termsConditionsNormalText}>
                              <Text
                                style={styles.termsConditionsColorText}
                                onPress={() => this.onPressTitle('Service')}>
                                {'Terms and conditions'}
                              </Text>
                              <Text style={styles.termsConditionsNormalText}> and </Text>
                              <Text
                                style={styles.termsConditionsColorText}
                                onPress={() => this.onPressTitle('Policy')}>
                                {'Privacy Policy'}
                              </Text>
                            </Text>
                          </View>
                        </View>
                      </Animatable.View>
                      <View style={styles.termsError}>
                        {this.checkError(props, 'privacy')
                          && <Text style={styles.error} >{props.errors.privacy}</Text>}
                      </View>
                      <Animatable.View animation="fadeInUp"
                        duration={500}
                        delay={1000} style={styles.bottomContainer}>
                        <View style={styles.accountOuterContainer}>
                          <TouchableOpacity
                            style={[styles.accountInnerContainer, styles.signupStyle]}
                            onPress={() => this.checkErrors(formikProps)}>
                            <View style={styles.alreadyView}>
                              <Text style={styles.needAccountText}>
                                {'SIGN UP'}
                              </Text>
                            </View>
                          </TouchableOpacity>
                        </View>
                      </Animatable.View>
                    </View> : null
                  }

                </React.Fragment>
              )
            }}
          </Formik>
        </KeyboardAwareScrollView>
      </View>
    );
  }
}


const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#f0f8ff'
  },
  container: {
    flexGrow: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',

  },
  welcomeImage: {
    marginBottom: hp('1%')
  },
  mainHeading: {
    fontSize: 50,
  },
  checkImage: {
    alignSelf: 'center',
  },
  subHeading: {
    marginBottom: 30
  },
  bottomContainer: {
    flex: 1,
    justifyContent: 'space-between',
  },
  needAccountText: {
    textAlign: 'center',
    color: 'white',
    fontSize: wp('3.6%'),
    fontSize: 16,
    paddingBottom: 2,

  },
  accountOuterContainer: {
    alignItems: 'center',
    marginBottom: wp('2%'),
  },
  accountInnerContainer: {
    width: 'auto',
  },
  termsError: {
    marginLeft: 10
  },
  error: {
    opacity: 0.91,
    alignSelf: 'flex-start',
    fontSize: wp('4%'),
    marginLeft: 3,
    color: 'red'
  },
  termsConditionOuterContainer: {
    marginTop: hp('2%'),
    marginBottom: hp('2%'),
    alignItems: 'flex-start',
    justifyContent: 'flex-start'
  },
  termsConditionInnerContainer: {
    flexDirection: 'row',
    height: 30,
    alignItems: 'center',
    justifyContent: 'center'
  },
  termsConditionsNormalText: {
    opacity: 0.75,
    marginRight: 10,
    marginLeft: 10,
    fontSize: wp('3.3%'),
  },
  termsConditionsColorText: {
    textAlign: 'center',
    color: '#00579e',
    fontSize: wp('3.3%'),
    textDecorationLine: 'underline',
  },
  termContainer: {
    flexDirection: 'column',
  },
  alreadyView: {
    opacity: 0.8,
    marginBottom: hp('2%'),
  },
  imagebackground: {
    width: '100%',
    height: '100%'
  },
  signupStyle: {
    backgroundColor: '#00579e',
    width: '90%',
    alignSelf: 'center',
    height: 50,
    textAlign: 'center',
    paddingTop: 15,
    borderRadius: 25,
  },
})

const mapStateToProps = state => ({
  signup: state.authentication.signUpUserResponse,
  isLoading: state.authentication.isLoading,
});

const mapDispatchToProps = () => UserActions;
const SignupScreen = connect(mapStateToProps, mapDispatchToProps)(Signup);
export default SignupScreen;

