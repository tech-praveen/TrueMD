/* eslint react/sort-comp: 0 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  StyleSheet,
  View,
  FlatList,
  Platform,
  Alert,
  AsyncStorage,
  Text
} from 'react-native';
import { images } from '../../assets/images';
import { showPopupAlert } from '../../utils/showAlert';
import SideMenuCell from './components/SideMenuCell';
import SideMenuHeader from './components/SideMenuHeader';
import { resetRoute } from '../../utils/utils_functions';
import constant, { color, width } from '../../config/appConfig';
// import { localizeStrings } from './localizeStrings';
import * as RootNavigation from '../../utils/navigation';

const leftPadding = (Platform.OS === 'android') ? 56 : 64;

const menuData = [
  {
    name: 'My Routes',
    icon: images.locationBlack,
  },
  {
    name: 'New Route',
    icon: images.locationBlack,
  },
  {
    name: 'Settings',
    icon: images.locationBlack,
  },
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  bodyView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatListStyle: {
    flex: 1,
    backgroundColor: '#f0f8ff'
  },
});

class Sidebar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      menuItems: menuData,
    };
  }

  onPressMenuItem(selectedItem) {
    console.log('********** menu', selectedItem, this.props.navigation);
    switch (selectedItem) {
      case 'My Routes':
        // this.props.navigation.navigate('DrawerClose');
        RootNavigation.navigate('MyRoute');
        break;
     
      case 'logout':
        this.props.navigation.navigate('DrawerClose');
        this.logoutUser();
        // showPopupAlert('This will be covered in next milestone');
        break;
      default:
        break;
        // Do nothing
    }
  }

  getRenderRow(data) {
    return (
      <SideMenuCell
        data={data.item}
        onPressMenuItem={selectedItem => this.onPressMenuItem(selectedItem)}
      />
    );
  }

  callLogoutRequest() {
    AsyncStorage.removeItem(constant.USER_DETAILS);
    resetRoute(this.props.navigation, 'Login');
    this.props.resetlogout();
  }

  // logoutUser() {
  //   Alert.alert(
  //     'Are you sure you want to logout?',
  //     '',
  //     [
  //       { text: 'Stay Log-in', onPress: () => {} },
  //       { text: 'Logout', onPress: () => this.callLogoutRequest(), style: 'destructive' },
  //     ],
  //   );
  // }

  render() {
    return (
      <View style={styles.container}>
        <SideMenuHeader />
        <View style={styles.bodyView}>
          <FlatList
            style={styles.flatListStyle}
            data={menuData}
            renderItem={data => this.getRenderRow(data)}
            keyExtractor={item => item.name}
            scrollEnabled={Boolean(true)}
          />
        </View>
      </View>
    );
  }
}

Sidebar.propTypes = {
  navigation: PropTypes.objectOf(PropTypes.any),
  resetlogout: PropTypes.func,
};

Sidebar.defaultProps = {
  navigation: {},
  resetlogout: () => {},
};

export default Sidebar;
