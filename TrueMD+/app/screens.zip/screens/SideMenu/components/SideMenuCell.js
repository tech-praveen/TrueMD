import React from 'react';
import PropTypes from 'prop-types';
import {
  StyleSheet,
  TouchableOpacity,
  Text,
  Image,
  View,
} from 'react-native';

const styles = StyleSheet.create({
  menuIconContainer: {
    paddingVertical: 8,
    paddingHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: 'white'
  },
  defaultIcon: {
    width: 25,
    height: 25,
    margin: 5,
    marginRight: 18,
  },
  defaultWhiteLabel: {
    fontSize: 17,
    color: '#00294C',
    // fontFamily: 'RobotoCondensed-Regular',
  },
});

const SideMenuCell = props => (
  <View style={{ flex: 1, borderWidth: 1,
    borderBottomColor: '#f0f8ff',
    borderRightColor: 'white',
    borderLeftColor: 'white',
    borderTopColor: 'white', }}>
    <TouchableOpacity
      style={styles.menuIconContainer}
      onPress={() => props.onPressMenuItem(props.data.name)}
    >
      <Image style={styles.defaultIcon} source={props.data.icon} />
      <Text style={styles.defaultWhiteLabel}>{props.data.name}</Text>
    </TouchableOpacity>
  </View>
);

SideMenuCell.propTypes = {
  label: PropTypes.string,
  icon: PropTypes.string,
  onPressMenuItem: PropTypes.func,
  active: PropTypes.bool,
};

SideMenuCell.defaultProps = {
  label: 'Label missing',
  icon: '',
  onPressMenuItem: undefined,
  active: false,
};

export default SideMenuCell;
