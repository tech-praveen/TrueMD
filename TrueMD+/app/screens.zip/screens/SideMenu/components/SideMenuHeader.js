import React from 'react';
import PropTypes from 'prop-types';
import {
  StyleSheet,
  Text,
  Image,
  View,
  Platform,
} from 'react-native';
import { images } from '../../../assets/images';
import { color, width } from '../../../config/appConfig';

const leftPadding = (Platform.OS === 'android') ? 56 : 64;

const styles = StyleSheet.create({
  viewProfileContainer: {
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderBottomColor: '#f0f8ff',
    borderRightColor: 'white',
    borderLeftColor: 'white',
    borderTopColor: 'white',
    paddingTop: 15,
  },
  viewProfile: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'white',
    borderWidth: 2,
  },
  avatarStyle: {
    width: 66,
    height: 66,
    borderRadius: 33,
  },
  largeWhiteLabel: {
    fontSize: 18,
    // color: 'white',
    // fontFamily: 'RobotoCondensed-Regular',
    marginTop: 5,
  },
  defaultWhiteLabel: {
    fontSize: 14,
    color: '#00294C',
    marginTop: 5,
  },
  lineView: {
    // position: 'absolute',
    height: 1,
    width: width - leftPadding,
    bottom: 0,
    opacity: 0.5,
    // backgroundColor: color.Orange,
  },
});

const SideMenuHeader = props => (
    <View style={styles.viewProfileContainer}>
      <View style={styles.viewProfile}>
        <Image
          style={styles.avatarStyle}
          source={images.profilePic}
        />
      </View>
      {/* <Text style={styles.largeWhiteLabel}>Jhon Smith</Text> */}
      <View >
        <View style={{ height: 50, justifyContent: 'center', alignItems: 'center'}} >
        <Text
            style={styles.defaultWhiteLabel}
          >{'8855446622'}
          </Text>
        <Text
            style={styles.defaultWhiteLabel}
          >{'customer@gnail.com'}
          </Text>
        </View>
        {/* <View style={{ height: 30 }} >
        </View> */}
      </View>

      {/* <View style={styles.lineView} /> */}
    </View>
);

SideMenuHeader.propTypes = {
  // label: PropTypes.string,
  // icon: PropTypes.string,
  // onPressMenuItem: PropTypes.func,
  // active: PropTypes.bool,
};

SideMenuHeader.defaultProps = {
  // label: 'Label missing',
  // icon: '',
  // onPressMenuItem: undefined,
  // active: false,
};

export default SideMenuHeader;
