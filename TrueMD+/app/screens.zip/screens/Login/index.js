import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import InputField from '../../components/InputField';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import { Formik } from 'formik';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import * as Animatable from "react-native-animatable";
import { images } from '../../assets/images';
// import {LoginSchema} from '../../utils/validations';
import NavigationBar from '../../components/NavigationBar';
import * as Yup from 'yup';
import { connect } from 'react-redux';
import UserActions from '../../actions';


const NumberRegex = /^[0-9]+$/;
const passwordDot = /^[^.]+$/;

const LoginSchema = Yup.object().shape({
  "phoneNumber": Yup.string()
    .trim()
    .required('Please enter valid user id'),

  "password": Yup.string().trim().required('Please enter your password')
    .matches(passwordDot, { excludeEmptyString: true, message: 'Please enter valid password' })
    .min(6, 'Password should be at least 8 characters long')
    .max(16, 'Password should be less than 16 characters')
});

class Login extends Component {

  static navigationOptions = ({ navigation }) => { // Custom Navigation
    return {
      headerLeft: (
        <TouchableOpacity
          style={{ height: 40, width: 40, backgroundColor: 'red' }}
          onPress={() => {
            navigation.navigate('Welcome');
          }
          }
        />
      ),
    };
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoaded: true
    }
  }

  checkErrors = (props) => { // Check Errors when SignIn button pressed
    if (props.dirty) {
      if (props.errors.phoneNumber) {
        Alert.alert('Please enter valid phone no');
        return;
      } else if (props.errors.password) {
        Alert.alert('Enter valid password');
        return;
      }
      props.submitForm();

    } else {
        Alert.alert('All fields should be mendatory');
    }
  }

  componentDidMount() {
  }

  popBack() {
    this.props.navigation.popBack();
  }

  checkError = (props, fieldName) => { // Check Error Individually for every field
    return props.errors[fieldName] && (props.touched[fieldName] || props.submitCount > 0)
  }

  onSignUpClicked() {
    this.props.navigation.navigate('SignUp');
  }

  onForgetPasswordClicked() {
    this.props.navigation.navigate('ForgotPassword');
  }

  render() {
    console.log('================', this.props);
    let formikProps;
    return (
      <Formik
        validationSchema={LoginSchema}
        initialValues={{ type: 'login', privacy: false, phoneNumber: '', password: '', errors: {} }}
        onSubmit={(values, { resetForm }) => {
          let body = {
            "email": values.phoneNumber,
            "password": values.password,
          }
          this.props.userLoginRequest(body);
        }}
      >
        {props => {
          formikProps = props;
          return (
            <View style={styles.mainContainer}>
              <NavigationBar
                showBackButton={Boolean(true)}
                backButtonAction={() => this.props.navigation.pop()}
                hideRightView={true}
              />
              <KeyboardAwareScrollView
                enableOnAndroid={true}
                contentContainerStyle={styles.mainContainer}
                keyboardShouldPersistTaps='handled' >
                <React.Fragment>
                  {
                    this.state.isLoaded ?
                      <View style={styles.container}>
                        <Animatable.View animation="flipInX"
                          duration={1000}
                          delay={200} style={styles.welcomeImage}>
                          <Image source={images.appLogo} />
                        </Animatable.View>
                        <Animatable.View animation="lightSpeedIn"
                          duration={1000}
                          delay={400} >
                          <InputField
                            label={'User name / Email / Mobile'}
                            onChangeText={props.handleChange('phoneNumber')}
                            onBlur={props.handleBlur('phoneNumber')}
                            value={props.values.phoneNumber}
                            maxLength={50}
                            keyboardType={'email-address'}
                          />
                          {this.checkError(props, 'phoneNumber')
                            && <Text style={styles.error} >
                              {props.errors.phoneNumber}
                            </Text>}
                        </Animatable.View>
                        <Animatable.View
                          animation="lightSpeedIn"
                          duration={1000}
                          delay={500} >
                          <InputField
                            onChangeText={props.handleChange('password')}
                            onBlur={props.handleBlur('password')}
                            value={props.values.password.trim()}
                            maxLength={30}
                            label={'Password'}
                            secureTextEntry={true}
                          />
                          {this.checkError(props, 'password')
                            && <Text style={styles.error} >
                              {props.errors.password}
                            </Text>}
                        </Animatable.View>
                        <Animatable.View animation="fadeInUp"
                          duration={500}
                          delay={700} style={styles.forgotPasswordOuterContainer}>
                          <TouchableOpacity
                            style={styles.forgotPasswordContainer}
                            onPress={() => this.onForgetPasswordClicked()}>
                            <View style={styles.forgotView}>
                              <Text style={styles.forgotPassword}>
                                {'Forgot Password'}
                              </Text>
                            </View>
                          </TouchableOpacity>
                        </Animatable.View>
                        <Animatable.View animation="fadeInUp"
                          duration={500}
                          delay={900} style={styles.bottomContainer}>
                          <TouchableOpacity
                            style={styles.signupStyle}
                            onPress={() => this.checkErrors(formikProps)}
                            >
                            <Text style={{ color: 'white', fontSize: 16 }}>
                              {'LOGIN'}
                            </Text>
                          </TouchableOpacity>
                          <View style={styles.needAccountOuterContainer}>
                            <TouchableOpacity
                              style={styles.needAccountInnerContainer}
                              onPress={() => this.onSignUpClicked()}>
                              <View style={styles.needAccountView}>
                                <Text style={styles.needAccountText}>
                                  {'Need New Account'}
                                </Text>
                              </View>
                            </TouchableOpacity>
                          </View>
                        </Animatable.View>
                      </View>
                      : null}
                </React.Fragment>
              </KeyboardAwareScrollView>
            </View>
          )
        }}
      </Formik>
    );
  }
}
// const mapDispatchToProps = dispatch => ({
//   userAuthentication: data => dispatch(Actions.userAuthentication(data)),
//   toggleLoader: state => dispatch(Actions.toggleLoader(state)),
// });

// export default Login
// connect(
//   null,
//   mapDispatchToProps
// )(Login);

const mapStateToProps = state => ({
  login: state.authentication.loginUserResponse,
  isLoading: state.authentication.isLoading,
});

const mapDispatchToProps = () => UserActions;
const LoginScreen = connect(mapStateToProps, mapDispatchToProps)(Login);
export default LoginScreen;

const styles = StyleSheet.create({
  mainContainer: {
    flexGrow: 1,
    backgroundColor: '#f0f8ff'
  },
  container: {
    flex: 1,
    paddingHorizontal: 20
  },
  bottomContainer: {
    flex: 1,
    justifyContent: 'space-between',
    paddingTop: hp('2%')
  },
  welcomeImage: {
    marginBottom: hp('10%')
  },
  mainHeading: {
    fontSize: 50
  },
  subHeading: {
    marginBottom: 30
  },
  forgotPasswordContainer: {
    width: 'auto'
  },
  forgotPasswordOuterContainer: {
    alignItems: 'flex-start'
  },
  forgotPassword: {
    fontSize: wp('3.2%'),
    marginTop: 10,
  },
  error: {
    opacity: 0.91,
    alignSelf: 'flex-start',
    fontSize: wp('4%'),
    marginLeft: 3,
    color: 'red'
  },
  needAccountOuterContainer: {
    alignItems: 'center'
  },
  needAccountInnerContainer: {
    width: 'auto',
    opacity: 0.8,
  },
  needAccountText: {
    textAlign: 'center',
    fontSize: wp('3.6%'),
    paddingBottom: 2,
  },
  needAccountView: {
    marginBottom: hp('3%'),
    opacity: 0.8,
    borderBottomWidth: 1,
    paddingBottom: 2,
  },
  forgotView: {
    opacity: 0.8,
    borderBottomWidth: 1,
    paddingBottom: 2,
  },
  signupStyle: {
    backgroundColor: '#00579E',
    width: '90%',
    alignSelf: 'center',
    height: 50,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
  },
  imagebackground: {
    width: '100%',
    height: '100%'
  },

})