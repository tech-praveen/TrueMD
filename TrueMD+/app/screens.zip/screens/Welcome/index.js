import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, ImageBackground } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import * as Animatable from "react-native-animatable";
import { images } from '../../assets/images';
export default class Welcome extends Component {

  static navigationOptions = { // Custom Navigation
    header: null,
  };

  constructor(props) {
    super();
    this.state = {
      winners: [1, 2, 3, 4, 5]
    }
  }

  handleSnapToItem = (index) => { // Winner swipe action
    console.log("snapped to ", index)
  }

  onSignUpClicked() {
    this.props.navigation.navigate('SignUp');
  }

  onLoginClicked() {
    this.props.navigation.navigate('Login');
  }

  render() {
    return (
      <View style={[styles.imagebackground, {backgroundColor: '#f0f8ff'}]}>
        <KeyboardAwareScrollView
          contentContainerStyle={styles.mainContainer}
          keyboardShouldPersistTaps='handled'
        >
          <View style={styles.container}>
            <Animatable.View animation="flipInX"
              duration={500}
              delay={1000} style={styles.lowerContainer}>
              <Text style={styles.welcomeText}>
                {'Welcome To'}
              </Text>
              <View style={styles.welcomeImage}>
                <Image source={images.appLogo} />
              </View>
            </Animatable.View>
            <Animatable.View animation="fadeInUp"
              duration={500}
              delay={2000} >

            <Text style={{margin: 20, fontSize: 17, textAlign: 'center'}}>
                  {'Route Planner is one of the best Application, its really good application.'}
                </Text>
              </Animatable.View>
            <Animatable.View animation="fadeInUp"
              duration={500}
              delay={2000} >
              <TouchableOpacity
                style={[styles.accountInnerContainer, styles.signupStyle]}
                onPress={() => this.onSignUpClicked()}>
                <Text style={styles.accountExist}>
                  {'SIGN UP'}
                </Text>
              </TouchableOpacity>
              <View style={styles.accountExistView}></View>
            </Animatable.View>
            <Animatable.View animation="fadeInUp"
              duration={500}
              delay={2500} style={styles.accountOuterContainer}>
              <TouchableOpacity
                style={styles.accountLoginButton}
                onPress={() => this.onLoginClicked()}>
                <View style={styles.accountExistView}>
                  <Text style={[styles.accountExist, {color: 'black'}]}>
                    {'Existing User'}
                  </Text>
                </View>
              </TouchableOpacity>
            </Animatable.View>
          </View>
        </KeyboardAwareScrollView>
      </View>
    );
  }
}


const styles = StyleSheet.create({
  mainContainer: {
    flexGrow: 1,
  },
  welcomeImage: {
    marginBottom: 5,
  },
  imagebackground: {
    width: '100%',
    height: '100%'
  },
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  upperContainer: {
    alignItems: 'flex-end',
    paddingTop: 20,
    flex: 0.3,
  },
  lowerContainer: {
    flex: 0.4,
    justifyContent: 'flex-end'
  },
  welcomeText: {
    color: 'black',
    paddingLeft: 5,
    fontSize: 10
  },
  sliderText: {
    color: 'black',
    fontSize: 20
  },

  accountOuterContainer: {
    alignItems: 'center'
  },
  accountLoginButton: {
    width: 'auto',
  },
  accountInnerContainer: {
    width: 'auto',
  },
  accountExist: {
    textAlign: 'center',
    color: 'white',
    fontSize: 16,
    opacity: 0.8,
    paddingBottom: 2,
    borderColor: 'black'
  },
  accountExistView: {
    borderBottomWidth: 1,
    paddingBottom: 2,
    borderColor: 'black',
    margin: 7,
  },
  signupStyle: {
    backgroundColor: '#00579E',
    width: '90%',
    alignSelf: 'center',
    height: 50,
    textAlign: 'center',
    paddingTop: 15,
    borderRadius: 25,
  }
})