/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  Text,
  View,
  Animated,
  Dimensions,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';
// import { NavigationActions } from 'react-navigation';
import StatusBar from '../../components/StatusBar';
const { width, height } = Dimensions.get('window');
import NavigationBar from '../../components/NavigationBar';
import images from '../../assets/images';
import { DrawerActions } from '@react-navigation/native';

import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import GetLocation from 'react-native-get-location'

export let navigatorObject = null;
const styles = StyleSheet.create({
  map: {
    height: 400,
    width: 400,
    // justifyContent: 'flex-end',
    // alignItems: 'center'
  }
});
class Home extends Component {
  constructor(props) {
    super(props);
    navigatorObject = props.navigation;
    this.state = {
      region: "",
      lat: null,
      long: null
    }
  }

  componentDidMount() {
    GetLocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 15000,
    })
      .then(location => {
        console.log("locationnnn", location);
        this.setState({
          lat: location.latitude,
          long: location.longitude
        })
      })
      .catch(error => {
        const { code, message } = error;
        console.warn(code, message);
      })
  }

  sideMenuAction = () => {
    console.log('===============');
    console.log('this.props.navigation', this.props.navigation);

    // this.props.navigation.dispatch(DrawerActions.toggleDrawer());
    this.props.navigation.openDrawer();
  }
  popBack() {
    const { goBack } = this.props.navigation;
    goBack(null);
  }
  render() {
    return (
      <View style={{ flex: 1 }}>
        <MapView
          provider={PROVIDER_GOOGLE} // remove if not using Google Maps
          style={{height: '100%', width: '100%', }, StyleSheet.absoluteFillObject}
          region={{
            latitude: 37.78825,
            longitude: -122.4324,
            latitudeDelta: 0.015,
            longitudeDelta: 0.0121,
          }}
        >
        </MapView>
        <TouchableOpacity
          activeOpacity={0.9}
          onPress={() => this.sideMenuAction()}
          style={{ color: 'black', top: 50, left: 20, width: 50, height: 50, backgroundColor: 'red', position: 'absolute' }}
        > 
        <Image
        source={props.menuIcon}
        resizeMode="contain" />
        </TouchableOpacity>
      </View>
    );
  }
}

Home.propTypes = {
  navigation: PropTypes.objectOf(PropTypes.any),
};

Home.defaultProps = {
  navigation: {},
};

export default Home;
